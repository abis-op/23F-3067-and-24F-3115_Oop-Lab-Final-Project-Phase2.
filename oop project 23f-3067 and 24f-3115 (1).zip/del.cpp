#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <fstream>

using namespace std;

// Game state structure
struct GameState {
    int gold;
    int food;
    int wood;
    int stone;
    int iron;
    int population;
    int soldiers;
    int morale;
    int popularity;
    int day;
    char kingdomName[50];
    char rulerName[50];
};

bool gameRunning = true;

void initializeGame(GameState* state) {
    state->gold = 1000;
    state->food = 500;
    state->wood = 300;
    state->stone = 200;
    state->iron = 100;
    state->population = 100;
    state->soldiers = 10;
    state->morale = 70;
    state->popularity = 60;
    state->day = 1;
    strcpy(state->kingdomName, "My Kingdom");
    strcpy(state->rulerName, "Player");
}

void displayStatus(const GameState* state) {
    system("cls || clear");
    cout << "=== " << state->kingdomName << " === Day " << state->day << " ===\n";
    cout << "Ruler: " << state->rulerName << "\n\n";
    cout << "RESOURCES:\n";
    cout << "Gold: " << state->gold << "\n";
    cout << "Food: " << state->food << "\n";
    cout << "Wood: " << state->wood << "\n";
    cout << "Stone: " << state->stone << "\n";
    cout << "Iron: " << state->iron << "\n\n";
    cout << "PEOPLE:\n";
    cout << "Population: " << state->population << "\n";
    cout << "Soldiers: " << state->soldiers << "\n";
    cout << "Morale: " << state->morale << "/100\n";
    cout << "Popularity: " << state->popularity << "/100\n\n";
}

void handleResources(GameState* state) {
    int choice;
    do {
        displayStatus(state);
        cout << "=== RESOURCE MANAGEMENT ===\n";
        cout << "1. Harvest Food (Costs 10 Gold, Gains 50-100 Food)\n";
        cout << "2. Cut Wood (Gains 20-40 Wood)\n";
        cout << "3. Mine Stone (Gains 10-20 Stone)\n";
        cout << "4. Mine Iron (Gains 5-15 Iron)\n";
        cout << "5. Return to Main Menu\n";
        cout << "Choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                if (state->gold >= 10) {
                    state->gold -= 10;
                    int gained = 50 + rand() % 51;
                    state->food += gained;
                    cout << "Harvested " << gained << " food!\n";
                } else {
                    cout << "Not enough gold!\n";
                }
                break;
            case 2:
                state->wood += 20 + rand() % 21;
                cout << "Gathered wood!\n";
                break;
            case 3:
                state->stone += 10 + rand() % 11;
                cout << "Mined stone!\n";
                break;
            case 4:
                state->iron += 5 + rand() % 11;
                cout << "Mined iron!\n";
                break;
        }
        if (choice != 5) {
            system("pause");
            state->day++;
        }
    } while (choice != 5);
}

void handlePopulation(GameState* state) {
    int choice;
    do {
        displayStatus(state);
        cout << "=== POPULATION MANAGEMENT ===\n";
        cout << "1. Build Houses (Costs 50 Wood, 20 Stone, +10 Population Capacity)\n";
        cout << "2. Distribute Food (Costs 50 Food, +5 Popularity)\n";
        cout << "3. Hold Festival (Costs 100 Gold, +10 Popularity, +5 Morale)\n";
        cout << "4. Return to Main Menu\n";
        cout << "Choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                if (state->wood >= 50 && state->stone >= 20) {
                    state->wood -= 50;
                    state->stone -= 20;
                    state->population += 10;
                    cout << "Built new houses! Population increased.\n";
                } else {
                    cout << "Not enough resources!\n";
                }
                break;
            case 2:
                if (state->food >= 50) {
                    state->food -= 50;
                    state->popularity = min(100, state->popularity + 5);
                    cout << "Distributed food to people!\n";
                } else {
                    cout << "Not enough food!\n";
                }
                break;
            case 3:
                if (state->gold >= 100) {
                    state->gold -= 100;
                    state->popularity = min(100, state->popularity + 10);
                    state->morale = min(100, state->morale + 5);
                    cout << "Festival was a success!\n";
                } else {
                    cout << "Not enough gold!\n";
                }
                break;
        }
        if (choice != 4) {
            system("pause");
            state->day++;
        }
    } while (choice != 4);
}

void handleMilitary(GameState* state) {
    int choice;
    do {
        displayStatus(state);
        cout << "=== MILITARY MANAGEMENT ===\n";
        cout << "1. Recruit Soldiers (Costs 50 Food, 10 Gold, 1 Population per Soldier)\n";
        cout << "2. Train Soldiers (Costs 20 Gold, +10 Morale)\n";
        cout << "3. Build Barracks (Costs 100 Wood, 50 Stone, +20 Soldier Capacity)\n";
        cout << "4. Return to Main Menu\n";
        cout << "Choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                if (state->food >= 50 && state->gold >= 10 && state->population > 0) {
                    state->food -= 50;
                    state->gold -= 10;
                    state->population--;
                    state->soldiers++;
                    cout << "Recruited a new soldier!\n";
                } else {
                    cout << "Requirements not met!\n";
                }
                break;
            case 2:
                if (state->gold >= 20 && state->soldiers > 0) {
                    state->gold -= 20;
                    state->morale = min(100, state->morale + 10);
                    cout << "Soldiers trained! Morale improved.\n";
                } else {
                    cout << "Requirements not met!\n";
                }
                break;
            case 3:
                if (state->wood >= 100 && state->stone >= 50) {
                    state->wood -= 100;
                    state->stone -= 50;
                    state->soldiers += 5;
                    cout << "Built new barracks! Military capacity increased.\n";
                } else {
                    cout << "Not enough resources!\n";
                }
                break;
        }
        if (choice != 4) {
            system("pause");
            state->day++;
        }
    } while (choice != 4);
}

void handleEconomy(GameState* state) {
    int choice;
    do {
        displayStatus(state);
        cout << "=== ECONOMIC MANAGEMENT ===\n";
        cout << "1. Collect Taxes (Gains 100 Gold, -5 Popularity)\n";
        cout << "2. Build Market (Costs 150 Wood, 50 Stone, +50 Gold per Day)\n";
        cout << "3. Trade Wood for Gold (10 Wood -> 15 Gold)\n";
        cout << "4. Return to Main Menu\n";
        cout << "Choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                state->gold += 100;
                state->popularity = max(0, state->popularity - 5);
                cout << "Taxes collected. People are grumbling.\n";
                break;
            case 2:
                if (state->wood >= 150 && state->stone >= 50) {
                    state->wood -= 150;
                    state->stone -= 50;
                    state->gold += 50;
                    cout << "Market built! Economy improved.\n";
                } else {
                    cout << "Not enough resources!\n";
                }
                break;
            case 3:
                if (state->wood >= 10) {
                    state->wood -= 10;
                    state->gold += 15;
                    cout << "Traded wood for gold.\n";
                } else {
                    cout << "Not enough wood!\n";
                }
                break;
        }
        if (choice != 4) {
            system("pause");
            state->day++;
        }
    } while (choice != 4);
}

void handleEvents(GameState* state) {
    displayStatus(state);
    cout << "=== RANDOM EVENT ===\n";

    int event = rand() % 4;
    switch (event) {
        case 0:
            cout << "Bountiful Harvest! +200 Food\n";
            state->food += 200;
            break;
        case 1:
            cout << "Bandit Raid! -100 Gold, -5 Morale\n";
            state->gold = max(0, state->gold - 100);
            state->morale = max(0, state->morale - 5);
            break;
        case 2:
            cout << "Miners Strike! -20 Stone, -10 Popularity\n";
            state->stone = max(0, state->stone - 20);
            state->popularity = max(0, state->popularity - 10);
            break;
        case 3:
            cout << "Foreign Merchants! +150 Gold\n";
            state->gold += 150;
            break;
    }
    state->day++;
    system("pause");
}

void saveGame(const GameState* state) {
    ofstream out("savegame.dat", ios::binary);
    if (out) {
        out.write((char*)state, sizeof(GameState));
        cout << "Game saved successfully!\n";
    } else {
        cout << "Failed to save game!\n";
    }
    system("pause");
}

void loadGame(GameState* state) {
    ifstream in("savegame.dat", ios::binary);
    if (in) {
        in.read((char*)state, sizeof(GameState));
        cout << "Game loaded successfully!\n";
    } else {
        cout << "No saved game found!\n";
    }
    system("pause");
}

void mainMenu(GameState* state) {
    int choice;
    do {
        displayStatus(state);
        cout << "=== MAIN MENU ===\n";
        cout << "1. Manage Resources\n";
        cout << "2. Manage Population\n";
        cout << "3. Manage Military\n";
        cout << "4. Manage Economy\n";
        cout << "5. Handle Events\n";
        cout << "6. Save Game\n";
        cout << "7. Load Game\n";
        cout << "8. Exit Game\n";
        cout << "Choice: ";
        cin >> choice;

        switch (choice) {
            case 1: handleResources(state); break;
            case 2: handlePopulation(state); break;
            case 3: handleMilitary(state); break;
            case 4: handleEconomy(state); break;
            case 5: handleEvents(state); break;
            case 6: saveGame(state); break;
            case 7: loadGame(state); break;
            case 8: gameRunning = false; break;
            default: cout << "Invalid choice!\n"; system("pause");
        }
    } while (gameRunning);
}

int main() {
    srand(time(0));
    GameState game;
    initializeGame(&game);

    cout << "=== STRONGHOLD KINGDOM SIMULATOR ===\n";
    cout << "Enter your kingdom name: ";
    cin.getline(game.kingdomName, 50);

    cout << "Enter your ruler name: ";
    cin.getline(game.rulerName, 50);

    mainMenu(&game);

    cout << "Game Over. Thank you for playing!\n";
    return 0;
}

